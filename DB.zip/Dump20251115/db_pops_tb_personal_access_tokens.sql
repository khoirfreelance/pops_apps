-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_pops
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_personal_access_tokens`
--

DROP TABLE IF EXISTS `tb_personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tb_personal_access_tokens_token_unique` (`token`),
  KEY `tb_personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `tb_personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_personal_access_tokens`
--

LOCK TABLES `tb_personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `tb_personal_access_tokens` DISABLE KEYS */;
INSERT INTO `tb_personal_access_tokens` VALUES (1,'App\\Models\\User',1,'api-token','3038f411f262b45f9b2470e67842c61b8e202d12d48663463af52a3077828b6e','[\"*\"]',NULL,NULL,'2025-09-13 16:49:58','2025-09-13 16:49:58'),(2,'App\\Models\\User',1,'api-token','23372b138171e6fdd74078c60537b0fecc8e1c5cb3241620a40913b454381c83','[\"*\"]',NULL,NULL,'2025-09-13 16:50:49','2025-09-13 16:50:49'),(3,'App\\Models\\User',1,'api-token','df89ff7e0328121fa5864758d0aa6efc043148c3308f2844cbf33497f11f0dc9','[\"*\"]',NULL,NULL,'2025-09-13 16:52:15','2025-09-13 16:52:15'),(4,'App\\Models\\User',1,'api-token','ca32ea7ae1b2f25bd8f1a3814e48fbf4863135894dca881a864ec3b5e3abefc1','[\"*\"]',NULL,NULL,'2025-09-13 16:55:32','2025-09-13 16:55:32'),(5,'App\\Models\\User',1,'api-token','6e13c828138b7386680f855ba1a81b289e254a51a13a9b9d2c2b9eac7a021a37','[\"*\"]',NULL,NULL,'2025-09-13 23:31:04','2025-09-13 23:31:04'),(6,'App\\Models\\User',1,'api-token','6a0b53836e43c5ee3efbb1142f02313cb97727f3345dced13aee4825865abb30','[\"*\"]','2025-09-13 23:48:42',NULL,'2025-09-13 23:47:30','2025-09-13 23:48:42'),(7,'App\\Models\\User',1,'api-token','54ac21b76ea8caadf2a56ccc0c14a2b4f81b6f9af07e347a43e82879b97f11da','[\"*\"]','2025-09-14 02:01:18',NULL,'2025-09-13 23:56:57','2025-09-14 02:01:18'),(8,'App\\Models\\User',1,'api-token','b294be47d6f530c0d8988e34c7d8f36b35b2e3ad3cb3931e6272165676f0be98','[\"*\"]',NULL,NULL,'2025-09-15 08:17:02','2025-09-15 08:17:02'),(9,'App\\Models\\User',1,'api-token','85e68b32bd4fdc049154b6c3432b2b8c8cd8d365692306a333e23907a62696ff','[\"*\"]',NULL,NULL,'2025-09-19 07:57:28','2025-09-19 07:57:28'),(10,'App\\Models\\User',1,'api-token','2d6971a730cd803592f89e2e79b2b3c1d59defc4880c7429031e258aaf1c5107','[\"*\"]',NULL,NULL,'2025-09-24 09:57:10','2025-09-24 09:57:10'),(11,'App\\Models\\User',1,'api-token','fc6d72d8eb13e9bb091d7263a6c12298ccef2d9d5f315e4576f15371b2e5e9e2','[\"*\"]','2025-09-25 08:22:01',NULL,'2025-09-24 09:59:58','2025-09-25 08:22:01'),(12,'App\\Models\\User',1,'api-token','0617919ddba5997fb9151f3d738f1c8aeb56730d86d3bcd4fab4ad38f45cf126','[\"*\"]','2025-09-25 08:33:57',NULL,'2025-09-25 08:24:17','2025-09-25 08:33:57'),(13,'App\\Models\\User',1,'api-token','924324480d86090d7f4d44fc71dd7bd7112d6290142f1a80796591b6fc633e7b','[\"*\"]',NULL,NULL,'2025-09-25 08:37:50','2025-09-25 08:37:50'),(14,'App\\Models\\User',1,'api-token','8e919281136a4637e96f6ee870bfebe1cd11a75dd38278f7b5f281d92b3006a6','[\"*\"]','2025-10-08 05:42:25',NULL,'2025-09-25 08:40:12','2025-10-08 05:42:25'),(15,'App\\Models\\User',1,'api-token','f52384ff434305f7d6358a3e947b5b3f7e2eb3b88092bace19cef357340dadbb','[\"*\"]',NULL,NULL,'2025-10-09 08:45:18','2025-10-09 08:45:18'),(16,'App\\Models\\User',1,'api-token','afbd6604a12ebe6069001589de7fdd2cd83862207dc023827c4898aa8943504c','[\"*\"]',NULL,NULL,'2025-10-09 08:45:20','2025-10-09 08:45:20'),(17,'App\\Models\\User',1,'api-token','ca8e427aa1359b435d798e1b2b8cc57d1db8ea004a11da41a2294965f1b7300e','[\"*\"]','2025-10-10 05:17:36',NULL,'2025-10-10 05:07:46','2025-10-10 05:17:36'),(18,'App\\Models\\User',1,'api-token','d66553f9893c05c4522f8ee84f021e7bb3bb7e1cfec0e11882dff1605a4f3101','[\"*\"]',NULL,NULL,'2025-10-10 05:18:50','2025-10-10 05:18:50'),(19,'App\\Models\\User',1,'api-token','b493ce4fd2074dc893bc6d42378878d6131ae83bc8075985c904a95abd1402a3','[\"*\"]',NULL,NULL,'2025-10-10 05:18:51','2025-10-10 05:18:51'),(20,'App\\Models\\User',1,'api-token','82b181c76d2a2496565d331e2ea1d9ad5b446bbe2f0acc42c705cd9d4a265856','[\"*\"]','2025-10-10 05:26:03',NULL,'2025-10-10 05:19:10','2025-10-10 05:26:03'),(21,'App\\Models\\User',1,'api-token','33eb65bab3998dfe1ad3bfdab2c4b7fb0171aa890430e0ce17a8eacb94feb917','[\"*\"]',NULL,NULL,'2025-10-10 05:28:48','2025-10-10 05:28:48'),(22,'App\\Models\\User',1,'api-token','933847f599ded019dbb1b31068cd60a033a043e2bd31024f23b63c8e8970071b','[\"*\"]','2025-11-01 10:28:58',NULL,'2025-10-10 05:29:06','2025-11-01 10:28:58'),(23,'App\\Models\\User',1,'api-token','49b356606b2064bbc8fc3d18af45778e97c5be3fb71354333bf25f29a1884560','[\"*\"]','2025-10-12 08:27:15',NULL,'2025-10-10 07:31:47','2025-10-12 08:27:15'),(24,'App\\Models\\User',1,'api-token','70c5c6d085ffccf94641531285a29637ca9a1aa83cd7ffe9636480b8e5f37a64','[\"*\"]','2025-10-26 09:12:04',NULL,'2025-10-12 15:17:17','2025-10-26 09:12:04'),(25,'App\\Models\\User',1,'api-token','8e7b128dc1f314d0373c495b2631c6c599cc51ecc9d0180720019fb5bb7e2acb','[\"*\"]','2025-11-11 21:24:42',NULL,'2025-10-27 07:57:03','2025-11-11 21:24:42'),(26,'App\\Models\\User',14,'api-token','29c187e4a20182ea9dabb75cd06d8be06b38fdb724f5c6e85a8ba0b5e3b05109','[\"*\"]','2025-11-14 21:48:20',NULL,'2025-11-11 21:25:27','2025-11-14 21:48:20'),(27,'App\\Models\\User',1,'api-token','0e13442b9344c0c28c919470783c24dcdc791e20451d5ff33d95044867f6e369','[\"*\"]','2025-11-13 02:09:53',NULL,'2025-11-13 01:31:51','2025-11-13 02:09:53');
/*!40000 ALTER TABLE `tb_personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-15 12:32:01
