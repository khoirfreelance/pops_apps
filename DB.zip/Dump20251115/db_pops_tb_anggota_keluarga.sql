-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: db_pops
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_anggota_keluarga`
--

DROP TABLE IF EXISTS `tb_anggota_keluarga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_anggota_keluarga` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_keluarga` int NOT NULL,
  `nik` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nama` varchar(150) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tempat_lahir` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `jenis_kelamin` enum('L','P') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status_hubungan` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `agama` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `pendidikan` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `pekerjaan` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status_perkawinan` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `kewarganegaraan` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `is_pending` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `modified_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nik` (`nik`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_anggota_keluarga`
--

LOCK TABLES `tb_anggota_keluarga` WRITE;
/*!40000 ALTER TABLE `tb_anggota_keluarga` DISABLE KEYS */;
INSERT INTO `tb_anggota_keluarga` VALUES (4,3,'3326160911950005','Dono Pradana Putra','Surabaya','1995-11-09','L','Kepala Keluarga','Islam','SARJANA','Karyawan','Kawin','WNI',0,'2025-09-19 16:42:23','2025-09-22 12:45:02'),(5,3,'3321022704990003','Nur Dini Waini','Jakarta','1999-04-27','P','Istri','Islam','SARJANA','Ibu Rumah Tangga','Kawin','WNI',0,'2025-09-20 06:30:32','2025-09-22 12:45:02'),(6,3,'3326160911120005','Edogawa Conan','Jakarta','2012-11-09','L','Anak','Islam','','','Belum Kawin','WNI',0,'2025-09-20 23:07:07','2025-09-22 12:45:02'),(7,4,'1871000910900009','Mugiwara no Luffy','Jakarta','1990-10-09','L','Kepala Keluarga','Islam','','Pegawai BUMN','Kawin','WNI',0,'2025-09-22 06:04:01','2025-09-22 17:03:18'),(8,4,'1871072310920219','Akagami No Shank','God Valley',NULL,NULL,'Famili Lain','Islam','DOKTORAL','Dosen','Cerai Mati','WNI',0,'2025-09-23 15:42:14','2025-09-28 04:08:20'),(9,4,'8712022904980003','Davy D. Xebec','Wes Blue','1998-04-29','L','Famili Lain','Islam','SARJANA','Karyawan Swasta','Belum Kawin','WNI',0,'2025-09-28 02:52:19','2025-09-28 02:52:19'),(10,5,'1879033001890002','Roronoa Zoro','Jakarta','1989-01-30','L','Kepala Keluarga','Islam','PROFESSOR','Peneliti','Belum Kawin','WNI',0,'2025-09-28 03:05:29','2025-09-28 03:05:29'),(11,5,'','Nico Robin',NULL,'2000-10-09','P','Anak','Islam','Sarjana','','Belum Kawin','WNI',1,'2025-09-28 07:04:08','2025-09-28 07:04:08');
/*!40000 ALTER TABLE `tb_anggota_keluarga` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-15 12:32:05
